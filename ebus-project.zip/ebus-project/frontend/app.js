import React, { useState, useEffect } from 'react';
import axios from 'axios';

function App() {
  const [buses, setBuses] = useState([]);

  useEffect(() => {
    const fetchBuses = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/buses');
        setBuses(response.data);
      } catch (error) {
        console.error('Error fetching bus data:', error);
      }
    };

    fetchBuses();
  }, []);

  return (
    <div className="App">
      <h1>Ebus Management System</h1>
      <ul>
        {buses.map(bus => (
          <li key={bus.id}>
            Bus {bus.id} is at Latitude: {bus.latitude}, Longitude: {bus.longitude}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
